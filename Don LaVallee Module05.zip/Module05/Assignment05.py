# Title: Working with Dictionaries#
# Dev:  DLaVallee
# Date:  November 12, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <DLaVallee>, 11/17/2018, Added code to complete assignment 5#
# Known bugs: None found in test unit test case step 1 thru 6

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Key= 'Name', Values = 'Task','Priority'}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# Initialize - Read persistent text file and display existing data (Step 1)
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Functions --#
def load_file_list():
# create a list and dictionary object to store the text data being read from the text file
    try:
        list_todo = []
        objfile = open("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "r")
#print (objfile.read ())-  remove comment tag to check to see what is in the raw file
#load text into list object
        list_todo = objfile.read().splitlines()
        print(list_todo)
#close the file to clear memory
        objfile.close()
    except IOError:
        print("Text File Could not be Opened!")

def load_file_dict():
    # create a list and dictionary object to store the text data being read from the text file
    try:
        dict_todo = {}
#dictionary created and will read text file into dictionary
        obj_file = open("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "r")
# print (obj_file.read ()) - remove comment tag to check to see what is in the raw file
# load text into dictionary object
        for row in obj_file:
            row.lstrip()
            x = row.rstrip('\n').split(',')
            a = x[0]
            b = x[1]
            s = ","
            dict_todo[a] = b + s
        print(dict_todo)

#Load the dictionary rows into a list object
        add_todo = []
        add_todo = obj_file.read().splitlines()
        #print(add_todo)
        add_todo.append(dict_todo)
        print('\n',"Last start-up step puts {Dictionary} into [List] object! - ",'\n', add_todo)

    except IOError:
        print("Text File Could not be Opened!")

def add_item():
    # open and read text file. Add item to the Multi-Dimension List of Dictionary key:value pairs
    try:
        objfile = open("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "r")
        # print (obj_file.read ()) remove comment tag to check to see what is in the raw file
        # load text into list object
        add_todo = objfile.read().splitlines()
        print(add_todo)
        while (True):
            str_value1 = str(input("Enter Task description: "))
            str_value2 = str(input("Enter Priority: "))
            print("I will insert : ", str_value1,",", str_value2)
            #save to dictionary for possible future manipulation
            dicNewRow = {str_value1, str_value2}
            strCommit = "no"  # set to no to validate user wants to take the action
            strCommit = str(input("Do you want to make this change in the Dictionary? yes or no : "))
            if (strCommit.strip () == 'yes'):
                print(" This a a preview of your new dictionary row: ", dicNewRow)
                add_todo.append(dicNewRow)
                print("Shows List containing original dictionary:  - ", add_todo)
            strWrite = str(input("Do you want to store this change in the text file? yes or no : "))
            if (strWrite.strip () == 'yes'):
                print("Writing all edits to text file: ", add_todo)
                objfile = open("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "w")
                objfile.write(str(add_todo))
                print(" New key:value pairs added! : ", add_todo)
                break

            else:
                print(" Nothing changed!")

        objfile.close()

    except IOError:
        print("Text File Could not be Opened!")

def remove_item():
    # create a list and dictionary object to store the text data being read from the text file
    try:
        dict_todo = {}
        # dictionary created and will read text file into dictionary
        obj_file = open ("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "r")
        # print (obj_file.read ()) - remove comment tag to check to see what is in the raw file
        # load text into dictionary object
        for row in obj_file:
            row.lstrip ()
            x = row.rstrip('\n').split(',')
            a = x[0]
            b = x[1]
            s = ","
            dict_todo[a] = b + s
        #print (dict_todo) - remove comment to assist in debugging for loop

        # Load the dictionary rows into a list object
        add_todo = []
        add_todo = obj_file.read ().splitlines ()
        # print(add_todo)
        add_todo.append (dict_todo)
        print(dict_todo)
        str_item = str(input("Enter Item to remove: "))
        if str_item in dict_todo:
            del dict_todo[str_item]
            print('Is it gone?','\n')
            print(dict_todo)

        else:
            print("Can't delete and item that is not there! Check your spelling?")

    except IOError:
        print("Text File Could not be Opened!")
#Open the text file to make sure it is there before the rest of script runs
try:
    objfile = open ("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "a+")
except IOError:
    print('Text file could not be opened!!!')

# -- Processing --#
# Step 1
# When the program starts, load data from a text file called ToDo.txt
objfile = open("C:\\_PythonClass\\assignment05\\module05\\ToDo.txt", "r")

#Display current list of Key:Value Pairs
print('\n','Starting script and loading text file data . . .','\n',
"The text file contains string values separated by comma as printed below . . .")
print(objfile.read())
print('\n',"Continued start-up with code that loaded the string values to dictionary key:value pairs!")
load_file_dict()
print('\n')

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line for console output spacing

    # Step 3 -Show the current items in the table
    if (strChoice.strip () == '1'):
        print("Below is your List and Dictionary objects showing Key:Value pairs {'Key':'Value1','Value2'}")
        load_file_list()
        load_file_dict()
        print("Above is a Multi-Dimension Table including unique Dictionary rows of Key,Value pairs!")
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip () == '2'):
        print('You selected to add a new Dictionary Row to the larger Multi-Dimension List!')
        add_item()
        continue
    # Step 5 - Remove a  item from the list/Table
    elif (strChoice == '3'):
        print('Select Item Description to be removed ...')
        remove_item()
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        print('Not implemented...')
        continue
    # Step 7 - Close the  text file ToDo.txt and close the script
    elif (strChoice == '5'):
        objfile.close()
        print('See You Next Time...')
        break  # stop any loops and final exit the program
