# Title:  - Pickling Assignment07 -
# Dev:  DLaVallee
# Date:  November 30, 2018
# ChangeLog: (Who, When, What)
# <DLaVallee>, 11/30/2018, Added code to complete assignment Module07 second part (Simplified)
# This script demonstrates what I learned working with 'Pickle string serialization to binary files.
# Known bugs: None found in test unit test case step 1 -

import pickle
#data ----
strFileName = "C:\_PythonClass\Assignment07\picklejar"
objFile = strFileName

#IO
objFileWrite = open (strFileName, 'wb')
objFileRead = open (strFileName, 'rb')
objFileAppend = open (strFileName, 'ab')
#print (objFile, ' this is your data as read from the file')

#processing ----
def ToString(strShape, strColor):
    return str (strShape) + "," + str (strColor) + str("\n")

#Presentation ----

strShape = str (input ("What is the Shape? - ")).strip ()
strColor = str (input ("What is the Color? [Red, Green, Blue, Black, White?] - ")).strip ()
strData = ToString(strShape, strColor)
pickle.dump (strData, objFileAppend) # stored binary data to file
objFileAppend.close()
# read the barrel
barrel = open(strFileName,"rb")
pickout = pickle.load(objFileRead)
print ( " All the Pickled objects from the barrel - ",'\n')
print ( 'This is your raw binary data extracted from the pickle barrel file!')
for line in barrel:
    print(line)
print ( 'This is your  binary data extracted and formatted back into text strings!')
print (barrel)
print (pickout)
objFileRead.close()
print (" - See you next time! -")